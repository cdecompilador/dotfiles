require("telescope").setup({
    defaults = {
        layout_strategy = "flex",
        layout_config = {
            width = 0.95,
            horizontal = {
                preview_cutoff = 0,
            },
            flex = {
                flip_columns = 200,
            },
        },
    },
    pickers = {
        find_files = {
            find_command = { "rg", "--files", 
                "--glob", "!**/.git/*", 
                "--glob", "!**/target/*" 
            },
        }
    }
})
