require('onedark').setup({
    style = "cool",
    code_style = {
        comments = "none",
    }
})

-- Hello World
