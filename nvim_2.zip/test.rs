use std::net::TcpListener;
use std::io::Read;

fn main() {
    let mut listener = TcpListener::bind("127.0.0.1:3000").unwrap();
    match listener.accept() {
        Ok((mut socket, addr)) => {
            println!("Connected {:?}", addr);

            let mut buf = [0; 4];
            socket.read(&mut buf).unwrap();

            println!("{:?}", buf);
        },
        Err(_) => panic!("Error"),
    }

}
