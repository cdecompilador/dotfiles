require("config")
require("remaps")

vim.cmd [[packadd packer.nvim]]

return require('packer').startup(function(use)
    -- Packer can manage itself
    use 'wbthomason/packer.nvim'

    use {
        'nvim-telescope/telescope.nvim', tag = '0.1.1',
        requires = { {'nvim-lua/plenary.nvim'} }
    }

    use {
        'navarasu/onedark.nvim',
        config = function()
            vim.cmd('colorscheme onedark')
        end
    }

    use {
        "williamboman/mason.nvim",
        run = ":MasonUpdate" -- :MasonUpdate updates registry contents
    }

    use 'williamboman/mason-lspconfig.nvim'
    use 'neovim/nvim-lspconfig'

    -- Nerd tree like
    use 'kyazdani42/nvim-tree.lua'

   --  use { 
   --      'ErichDonGubler/lsp_lines.nvim',
   --      requires = { 
   --          { 'folke/trouble.nvim' }
   --      }
   --  }
end)


